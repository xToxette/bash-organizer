#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("Main process id: %d\nForkbomb ahead!\n", getpid());
    while(1) {
        fork();
        sleep(1);
    }
}
