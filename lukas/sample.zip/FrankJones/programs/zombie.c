#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("Main process id: %d\n\n", getpid());
    int result = fork();
    if(result == 0) {
        printf("In child process with id %d\n", getpid());
        printf("This process terminates, but the parent won't reap it yet.\n");
        printf("The child process therefore becomes a zombie.\n");
        printf("Pressing Ctrl-C will end the main process and the zombie child with it.\n");
    } else {
        while(1) ;
    }
    return 0;
}
