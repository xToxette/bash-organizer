#include <stdio.h>
#include <stdlib.h>

int a = 57;

int main()
{
    int n = 1729;
    int *p = malloc(1024 * 1024 * sizeof(int));
    int *q = malloc(1024 * 1024 * sizeof(int));
    printf("Heap variable p is at address %p\n", p);
    printf("Heap variable q is at address %p\n", q);
    printf("Global variable a is at address %p\n", &a);
    printf("Local variable n is at address %p\n", &n);
    printf("Function main() is at address %p\n", &main);
    while(1) ;  /* Infinite loop */
    return 0;
}
