#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("Main process id: %d\n\n", getpid());
    int result = fork();
    if(result == 0) {
        printf("In child process with id %d\n", getpid());
    } else {
        printf("In parent process with id %d and child id %d\n", getpid(), result);
    }
    return 0;
}
